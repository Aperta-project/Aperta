// jQuery(document).ready(function() {
//   if (typeof CKEDITOR != 'undefined'){
//     CKEDITOR.replace('abstract_editable', {
//       "toolbarGroups": [
//         { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
//         { name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align' ] },
//         { name: 'styles' },
//         { name: 'colors' },
//         { name: 'about' }
//       ]
//     });
//
//     CKEDITOR.replace('body_editable', {
//       "disableAutoInline": false,
//       "autoGrow_onStartup": true,
//       "toolbarGroups": [
//         { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
//         { name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align' ] },
//         { name: 'styles' },
//         { name: 'colors' },
//         { name: 'about' }
//       ]
//     });
//   }
// });
